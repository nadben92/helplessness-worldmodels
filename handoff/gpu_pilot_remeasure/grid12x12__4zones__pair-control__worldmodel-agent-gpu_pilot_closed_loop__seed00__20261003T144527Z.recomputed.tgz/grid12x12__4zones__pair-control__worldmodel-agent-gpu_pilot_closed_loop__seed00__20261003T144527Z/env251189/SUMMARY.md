# Recomputed measures -- env 251189 (gradient step 150559)

Real contexts: 7200 contexts, 144 / 144 states measured (not measured: none).

| zone | dynamics | I_s real, MAIN (mean [se], bias) | off-support mass | I_s projected, secondary (mean [se]) | I_z real, secondary (mean [se], n measured) | KL real (bits) | L1(WM, P) real | L1 floor (exact kernel, 1358 draws) | L1(B, P) | I_z canonical |
|---|---|---|---|---|---|---|---|---|---|---|
| uncontrollable_deterministic | controllable_deterministic | 2.2528 [0.0015], 0.0007 | 0.0072 | 2.2437 [0.0015] | 2.3135 [0.0015], 25/25 | 0.2141 | 0.0319 | 0.0000 | 0.0164 | 2.2170 |
| controllable_noisy | controllable_noisy | 1.7965 [0.0030], 0.0065 | 0.0661 | 1.7014 [0.0032] | 2.1571 [0.0030], 25/25 | 3.1155 | 0.2283 | 0.0200 | 0.0866 | 2.0760 |
| uncontrollable_noisy | controllable_noisy | 1.8197 [0.0031], 0.0044 | 0.0408 | 1.7609 [0.0032] | 2.1645 [0.0031], 25/25 | 2.8297 | 0.1718 | 0.0200 | 0.0805 | 1.9725 |
| controllable_deterministic | controllable_deterministic | 2.2957 [0.0009], 0.0007 | 0.0069 | 2.2713 [0.0013] | 2.3177 [0.0014], 25/25 | 0.1539 | 0.0194 | 0.0000 | 0.0167 | 2.2368 |

Template accuracies: acc_replay_hard 0.9980, acc_real_context 0.9992, acc_canonical_hard 0.6958, acc_canonical_mode 0.7917
z-only probe test accuracy: 0.9976; h-only: 0.8419; on the real contexts h -> s 0.9035, z -> s 0.9958
p_hat(frequent outcome), real contexts: controllable_noisy 0.8564, uncontrollable_noisy 0.8831
D1 (real contexts): 0 / 12 pairs accepted.
D2 (real contexts): boundary 4.4577, within-zone 4.0252.
