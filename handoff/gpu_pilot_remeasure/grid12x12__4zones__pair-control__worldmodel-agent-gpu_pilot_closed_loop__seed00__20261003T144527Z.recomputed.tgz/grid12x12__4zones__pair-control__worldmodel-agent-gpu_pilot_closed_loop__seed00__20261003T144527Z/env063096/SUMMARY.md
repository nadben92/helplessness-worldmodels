# Recomputed measures -- env 63096 (gradient step 37703)

Real contexts: 7200 contexts, 144 / 144 states measured (not measured: none).

| zone | dynamics | I_s real, MAIN (mean [se], bias) | off-support mass | I_s projected, secondary (mean [se]) | I_z real, secondary (mean [se], n measured) | KL real (bits) | L1(WM, P) real | L1 floor (exact kernel, 1358 draws) | L1(B, P) | I_z canonical |
|---|---|---|---|---|---|---|---|---|---|---|
| uncontrollable_deterministic | controllable_deterministic | 2.0479 [0.0023], 0.0017 | 0.0381 | 2.0140 [0.0024] | 2.2774 [0.0018], 25/25 | 0.8837 | 0.1620 | 0.0000 | 0.0281 | 2.2034 |
| controllable_noisy | controllable_noisy | 1.4165 [0.0032], 0.0100 | 0.2247 | 1.2069 [0.0033] | 2.0258 [0.0030], 25/25 | 4.9330 | 0.5947 | 0.0200 | 0.1230 | 1.9261 |
| uncontrollable_noisy | controllable_noisy | 1.5558 [0.0032], 0.0075 | 0.1201 | 1.4399 [0.0034] | 2.0715 [0.0033], 25/25 | 3.8754 | 0.3941 | 0.0200 | 0.1055 | 1.9396 |
| controllable_deterministic | controllable_deterministic | 2.2415 [0.0015], 0.0023 | 0.0271 | 2.1791 [0.0019] | 2.3125 [0.0015], 25/25 | 0.6480 | 0.0703 | 0.0000 | 0.0317 | 2.2730 |

Template accuracies: acc_replay_hard 0.9941, acc_real_context 0.9988, acc_canonical_hard 0.7306, acc_canonical_mode 0.7778
z-only probe test accuracy: 0.9978; h-only: 0.8520; on the real contexts h -> s 0.9028, z -> s 0.9958
p_hat(frequent outcome), real contexts: controllable_noisy 0.6544, uncontrollable_noisy 0.7535
D1 (real contexts): 4 / 12 pairs accepted.
D2 (real contexts): boundary 4.3126, within-zone 3.9510.
