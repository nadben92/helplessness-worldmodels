# Recomputed measures -- env 158489 (gradient step 94939)

Real contexts: 7200 contexts, 144 / 144 states measured (not measured: none).

| zone | dynamics | I_s real, MAIN (mean [se], bias) | off-support mass | I_s projected, secondary (mean [se]) | I_z real, secondary (mean [se], n measured) | KL real (bits) | L1(WM, P) real | L1 floor (exact kernel, 1358 draws) | L1(B, P) | I_z canonical |
|---|---|---|---|---|---|---|---|---|---|---|
| uncontrollable_deterministic | controllable_deterministic | 2.2137 [0.0017], 0.0012 | 0.0123 | 2.1954 [0.0018] | 2.3069 [0.0016], 25/25 | 0.3410 | 0.0538 | 0.0000 | 0.0205 | 2.2145 |
| controllable_noisy | controllable_noisy | 1.7683 [0.0030], 0.0071 | 0.0792 | 1.6495 [0.0033] | 2.1457 [0.0029], 25/25 | 3.5080 | 0.2569 | 0.0200 | 0.0945 | 2.0530 |
| uncontrollable_noisy | controllable_noisy | 1.8011 [0.0030], 0.0046 | 0.0484 | 1.7386 [0.0032] | 2.1524 [0.0031], 25/25 | 3.2424 | 0.1951 | 0.0200 | 0.0873 | 1.9242 |
| controllable_deterministic | controllable_deterministic | 2.2844 [0.0011], 0.0011 | 0.0092 | 2.2563 [0.0015] | 2.3187 [0.0014], 25/25 | 0.2028 | 0.0267 | 0.0000 | 0.0208 | 2.2542 |

Template accuracies: acc_replay_hard 1.0000, acc_real_context 0.9979, acc_canonical_hard 0.6486, acc_canonical_mode 0.7222
z-only probe test accuracy: 0.9979; h-only: 0.8501; on the real contexts h -> s 0.9049, z -> s 0.9938
p_hat(frequent outcome), real contexts: controllable_noisy 0.8375, uncontrollable_noisy 0.8700
D1 (real contexts): 0 / 12 pairs accepted.
D2 (real contexts): boundary 4.4307, within-zone 3.9953.
