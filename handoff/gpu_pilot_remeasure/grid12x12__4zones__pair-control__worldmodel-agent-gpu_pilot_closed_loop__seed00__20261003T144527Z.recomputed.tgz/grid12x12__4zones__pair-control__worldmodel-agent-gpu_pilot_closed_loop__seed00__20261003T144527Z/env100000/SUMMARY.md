# Recomputed measures -- env 100000 (gradient step 59846)

Real contexts: 7200 contexts, 144 / 144 states measured (not measured: none).

| zone | dynamics | I_s real, MAIN (mean [se], bias) | off-support mass | I_s projected, secondary (mean [se]) | I_z real, secondary (mean [se], n measured) | KL real (bits) | L1(WM, P) real | L1 floor (exact kernel, 1358 draws) | L1(B, P) | I_z canonical |
|---|---|---|---|---|---|---|---|---|---|---|
| uncontrollable_deterministic | controllable_deterministic | 2.1844 [0.0019], 0.0015 | 0.0175 | 2.1672 [0.0020] | 2.3009 [0.0017], 25/25 | 0.4543 | 0.0727 | 0.0000 | 0.0245 | 2.2121 |
| controllable_noisy | controllable_noisy | 1.6580 [0.0031], 0.0077 | 0.1313 | 1.4927 [0.0034] | 2.1259 [0.0029], 25/25 | 3.7364 | 0.3659 | 0.0200 | 0.1074 | 1.9972 |
| uncontrollable_noisy | controllable_noisy | 1.7384 [0.0031], 0.0052 | 0.0694 | 1.6589 [0.0033] | 2.1383 [0.0029], 25/25 | 3.9537 | 0.2497 | 0.0200 | 0.0983 | 1.9586 |
| controllable_deterministic | controllable_deterministic | 2.2640 [0.0012], 0.0017 | 0.0170 | 2.2176 [0.0017] | 2.3171 [0.0014], 25/25 | 0.4368 | 0.0461 | 0.0000 | 0.0257 | 2.2709 |

Template accuracies: acc_replay_hard 0.9980, acc_real_context 0.9983, acc_canonical_hard 0.6264, acc_canonical_mode 0.7222
z-only probe test accuracy: 0.9980; h-only: 0.8503; on the real contexts h -> s 0.9021, z -> s 0.9972
p_hat(frequent outcome), real contexts: controllable_noisy 0.7753, uncontrollable_noisy 0.8364
D1 (real contexts): 0 / 12 pairs accepted.
D2 (real contexts): boundary 4.3574, within-zone 3.9563.
