# Recomputed measures -- env 300000 (gradient step 179846)

Real contexts: 7200 contexts, 144 / 144 states measured (not measured: none).

| zone | dynamics | I_s real, MAIN (mean [se], bias) | off-support mass | I_s projected, secondary (mean [se]) | I_z real, secondary (mean [se], n measured) | KL real (bits) | L1(WM, P) real | L1 floor (exact kernel, 1358 draws) | L1(B, P) | I_z canonical |
|---|---|---|---|---|---|---|---|---|---|---|
| uncontrollable_deterministic | controllable_deterministic | 2.2649 [0.0013], 0.0008 | 0.0061 | 2.2543 [0.0014] | 2.3153 [0.0014], 25/25 | 0.1463 | 0.0262 | 0.0000 | 0.0149 | 2.2157 |
| controllable_noisy | controllable_noisy | 1.7921 [0.0031], 0.0059 | 0.0613 | 1.6948 [0.0033] | 2.1544 [0.0030], 25/25 | 2.8406 | 0.2242 | 0.0200 | 0.0803 | 2.0548 |
| uncontrollable_noisy | controllable_noisy | 1.8349 [0.0031], 0.0044 | 0.0407 | 1.7775 [0.0033] | 2.1649 [0.0031], 25/25 | 2.6707 | 0.1806 | 0.0200 | 0.0776 | 1.9703 |
| controllable_deterministic | controllable_deterministic | 2.2981 [0.0009], 0.0007 | 0.0066 | 2.2793 [0.0012] | 2.3183 [0.0013], 25/25 | 0.1479 | 0.0182 | 0.0000 | 0.0153 | 2.2289 |

Template accuracies: acc_replay_hard 0.9961, acc_real_context 0.9990, acc_canonical_hard 0.7389, acc_canonical_mode 0.8611
z-only probe test accuracy: 0.9974; h-only: 0.8397; on the real contexts h -> s 0.8993, z -> s 0.9972
p_hat(frequent outcome), real contexts: controllable_noisy 0.8597, uncontrollable_noisy 0.8863
D1 (real contexts): 0 / 12 pairs accepted.
D2 (real contexts): boundary 4.4681, within-zone 4.0357.
