# Recomputed measures -- env 63096 (gradient step 37703)

Real contexts: 7200 contexts, 144 / 144 states measured (not measured: none).

| zone | dynamics | I_s real, MAIN (mean [se], bias) | off-support mass | I_s projected, secondary (mean [se]) | I_z real, secondary (mean [se], n measured) | KL real (bits) | L1(WM, P) real | L1 floor (exact kernel, 1358 draws) | L1(B, P) | I_z canonical |
|---|---|---|---|---|---|---|---|---|---|---|
| uncontrollable_deterministic | controllable_deterministic | 2.1657 [0.0018], 0.0044 | 0.0462 | 2.0934 [0.0023] | 2.3011 [0.0018], 25/25 | 1.0242 | 0.1236 | 0.0000 | 0.0315 | 2.2422 |
| controllable_noisy | controllable_noisy | 1.7307 [0.0030], 0.0071 | 0.1175 | 1.6759 [0.0032] | 2.1815 [0.0024], 25/25 | 4.2467 | 0.3427 | 0.0200 | 0.1045 | 2.0958 |
| uncontrollable_noisy | controllable_noisy | 1.2441 [0.0032], 0.0052 | 0.1615 | 1.1545 [0.0033] | 1.9878 [0.0034], 25/25 | 4.6898 | 0.6047 | 0.0200 | 0.1084 | 2.0227 |
| controllable_deterministic | controllable_deterministic | 2.2108 [0.0016], 0.0029 | 0.0412 | 2.1317 [0.0021] | 2.3121 [0.0016], 25/25 | 0.8097 | 0.1020 | 0.0000 | 0.0287 | 2.2431 |

Template accuracies: acc_replay_hard 1.0000, acc_real_context 0.9974, acc_canonical_hard 0.6000, acc_canonical_mode 0.6111
z-only probe test accuracy: 0.9990; h-only: 0.8739; on the real contexts h -> s 0.9181, z -> s 0.9924
p_hat(frequent outcome), real contexts: controllable_noisy 0.7964, uncontrollable_noisy 0.6346
D1 (real contexts): 4 / 12 pairs accepted.
D2 (real contexts): boundary 4.2459, within-zone 4.1252.
