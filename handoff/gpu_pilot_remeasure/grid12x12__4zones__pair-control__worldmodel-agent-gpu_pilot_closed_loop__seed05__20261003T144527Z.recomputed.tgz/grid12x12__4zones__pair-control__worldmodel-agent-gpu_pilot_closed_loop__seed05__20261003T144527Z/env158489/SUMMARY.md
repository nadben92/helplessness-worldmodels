# Recomputed measures -- env 158489 (gradient step 94939)

Real contexts: 7200 contexts, 144 / 144 states measured (not measured: none).

| zone | dynamics | I_s real, MAIN (mean [se], bias) | off-support mass | I_s projected, secondary (mean [se]) | I_z real, secondary (mean [se], n measured) | KL real (bits) | L1(WM, P) real | L1 floor (exact kernel, 1358 draws) | L1(B, P) | I_z canonical |
|---|---|---|---|---|---|---|---|---|---|---|
| uncontrollable_deterministic | controllable_deterministic | 2.2791 [0.0011], 0.0011 | 0.0114 | 2.2502 [0.0015] | 2.3198 [0.0015], 25/25 | 0.2505 | 0.0318 | 0.0000 | 0.0207 | 2.2167 |
| controllable_noisy | controllable_noisy | 1.8732 [0.0028], 0.0057 | 0.0579 | 1.8238 [0.0031] | 2.2225 [0.0025], 25/25 | 3.2741 | 0.2168 | 0.0200 | 0.0771 | 2.0423 |
| uncontrollable_noisy | controllable_noisy | 1.5972 [0.0032], 0.0041 | 0.0822 | 1.5420 [0.0033] | 2.1232 [0.0030], 25/25 | 3.3752 | 0.3044 | 0.0200 | 0.0824 | 2.0532 |
| controllable_deterministic | controllable_deterministic | 2.2796 [0.0011], 0.0013 | 0.0127 | 2.2533 [0.0014] | 2.3226 [0.0014], 25/25 | 0.3425 | 0.0347 | 0.0000 | 0.0212 | 2.2396 |

Template accuracies: acc_replay_hard 0.9961, acc_real_context 0.9985, acc_canonical_hard 0.3931, acc_canonical_mode 0.4097
z-only probe test accuracy: 0.9990; h-only: 0.8488; on the real contexts h -> s 0.9028, z -> s 0.9986
p_hat(frequent outcome), real contexts: controllable_noisy 0.8734, uncontrollable_noisy 0.7969
D1 (real contexts): 0 / 12 pairs accepted.
D2 (real contexts): boundary 4.3487, within-zone 4.2056.
