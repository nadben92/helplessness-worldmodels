# Recomputed measures -- env 300000 (gradient step 179846)

Real contexts: 7200 contexts, 144 / 144 states measured (not measured: none).

| zone | dynamics | I_s real, MAIN (mean [se], bias) | off-support mass | I_s projected, secondary (mean [se]) | I_z real, secondary (mean [se], n measured) | KL real (bits) | L1(WM, P) real | L1 floor (exact kernel, 1358 draws) | L1(B, P) | I_z canonical |
|---|---|---|---|---|---|---|---|---|---|---|
| uncontrollable_deterministic | controllable_deterministic | 2.2888 [0.0010], 0.0008 | 0.0062 | 2.2712 [0.0013] | 2.3188 [0.0015], 25/25 | 0.1908 | 0.0200 | 0.0000 | 0.0154 | 2.1935 |
| controllable_noisy | controllable_noisy | 1.9511 [0.0028], 0.0058 | 0.0449 | 1.9017 [0.0030] | 2.2318 [0.0026], 25/25 | 3.2056 | 0.1735 | 0.0200 | 0.0620 | 2.0544 |
| uncontrollable_noisy | controllable_noisy | 1.6457 [0.0032], 0.0039 | 0.0641 | 1.6075 [0.0033] | 2.1496 [0.0032], 25/25 | 2.8871 | 0.2622 | 0.0200 | 0.0686 | 2.0248 |
| controllable_deterministic | controllable_deterministic | 2.2897 [0.0010], 0.0010 | 0.0093 | 2.2650 [0.0012] | 2.3203 [0.0013], 25/25 | 0.1845 | 0.0252 | 0.0000 | 0.0154 | 2.1808 |

Template accuracies: acc_replay_hard 0.9980, acc_real_context 0.9976, acc_canonical_hard 0.4319, acc_canonical_mode 0.4653
z-only probe test accuracy: 0.9989; h-only: 0.8430; on the real contexts h -> s 0.9201, z -> s 0.9979
p_hat(frequent outcome), real contexts: controllable_noisy 0.9042, uncontrollable_noisy 0.8240
D1 (real contexts): 0 / 12 pairs accepted.
D2 (real contexts): boundary 4.4525, within-zone 4.3002.
