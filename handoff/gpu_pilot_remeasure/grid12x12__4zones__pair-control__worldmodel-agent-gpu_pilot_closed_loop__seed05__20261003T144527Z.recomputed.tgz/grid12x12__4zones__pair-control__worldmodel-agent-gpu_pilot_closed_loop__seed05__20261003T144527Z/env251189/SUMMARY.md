# Recomputed measures -- env 251189 (gradient step 150559)

Real contexts: 7200 contexts, 144 / 144 states measured (not measured: none).

| zone | dynamics | I_s real, MAIN (mean [se], bias) | off-support mass | I_s projected, secondary (mean [se]) | I_z real, secondary (mean [se], n measured) | KL real (bits) | L1(WM, P) real | L1 floor (exact kernel, 1358 draws) | L1(B, P) | I_z canonical |
|---|---|---|---|---|---|---|---|---|---|---|
| uncontrollable_deterministic | controllable_deterministic | 2.2848 [0.0011], 0.0010 | 0.0072 | 2.2652 [0.0013] | 2.3195 [0.0014], 25/25 | 0.1856 | 0.0233 | 0.0000 | 0.0169 | 2.1998 |
| controllable_noisy | controllable_noisy | 1.9319 [0.0028], 0.0056 | 0.0487 | 1.8837 [0.0030] | 2.2285 [0.0025], 25/25 | 3.4344 | 0.1860 | 0.0200 | 0.0660 | 2.0405 |
| uncontrollable_noisy | controllable_noisy | 1.6247 [0.0033], 0.0037 | 0.0710 | 1.5790 [0.0034] | 2.1335 [0.0031], 25/25 | 3.1962 | 0.2797 | 0.0200 | 0.0696 | 2.0544 |
| controllable_deterministic | controllable_deterministic | 2.2909 [0.0010], 0.0007 | 0.0084 | 2.2671 [0.0013] | 2.3208 [0.0013], 25/25 | 0.1930 | 0.0240 | 0.0000 | 0.0170 | 2.2081 |

Template accuracies: acc_replay_hard 0.9980, acc_real_context 0.9975, acc_canonical_hard 0.4028, acc_canonical_mode 0.4861
z-only probe test accuracy: 0.9986; h-only: 0.8434; on the real contexts h -> s 0.9021, z -> s 0.9986
p_hat(frequent outcome), real contexts: controllable_noisy 0.8956, uncontrollable_noisy 0.8136
D1 (real contexts): 0 / 12 pairs accepted.
D2 (real contexts): boundary 4.4319, within-zone 4.2634.
