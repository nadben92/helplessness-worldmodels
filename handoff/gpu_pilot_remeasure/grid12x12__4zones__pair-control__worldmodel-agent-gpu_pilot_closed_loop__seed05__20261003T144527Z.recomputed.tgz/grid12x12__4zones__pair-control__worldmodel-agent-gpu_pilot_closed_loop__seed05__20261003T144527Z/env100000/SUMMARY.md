# Recomputed measures -- env 100000 (gradient step 59846)

Real contexts: 7200 contexts, 144 / 144 states measured (not measured: none).

| zone | dynamics | I_s real, MAIN (mean [se], bias) | off-support mass | I_s projected, secondary (mean [se]) | I_z real, secondary (mean [se], n measured) | KL real (bits) | L1(WM, P) real | L1 floor (exact kernel, 1358 draws) | L1(B, P) | I_z canonical |
|---|---|---|---|---|---|---|---|---|---|---|
| uncontrollable_deterministic | controllable_deterministic | 2.2492 [0.0014], 0.0024 | 0.0196 | 2.2066 [0.0019] | 2.3139 [0.0016], 25/25 | 0.5321 | 0.0545 | 0.0000 | 0.0254 | 2.2373 |
| controllable_noisy | controllable_noisy | 1.8449 [0.0029], 0.0061 | 0.0753 | 1.7992 [0.0032] | 2.2163 [0.0024], 25/25 | 3.7172 | 0.2367 | 0.0200 | 0.0883 | 2.0882 |
| uncontrollable_noisy | controllable_noisy | 1.5327 [0.0033], 0.0046 | 0.0981 | 1.4738 [0.0033] | 2.0983 [0.0029], 25/25 | 3.6072 | 0.3605 | 0.0200 | 0.0929 | 2.0371 |
| controllable_deterministic | controllable_deterministic | 2.2624 [0.0013], 0.0020 | 0.0184 | 2.2196 [0.0017] | 2.3183 [0.0015], 25/25 | 0.4423 | 0.0488 | 0.0000 | 0.0253 | 2.2424 |

Template accuracies: acc_replay_hard 1.0000, acc_real_context 0.9982, acc_canonical_hard 0.5028, acc_canonical_mode 0.5347
z-only probe test accuracy: 0.9990; h-only: 0.8597; on the real contexts h -> s 0.9236, z -> s 0.9979
p_hat(frequent outcome), real contexts: controllable_noisy 0.8565, uncontrollable_noisy 0.7662
D1 (real contexts): 0 / 12 pairs accepted.
D2 (real contexts): boundary 4.2266, within-zone 4.1430.
