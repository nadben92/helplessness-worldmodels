# Recomputed measures -- env 251189 (gradient step 150559)

Real contexts: 7110 contexts, 144 / 144 states measured (not measured: none).

| zone | dynamics | I_s real, MAIN (mean [se], bias) | off-support mass | I_s projected, secondary (mean [se]) | I_z real, secondary (mean [se], n measured) | KL real (bits) | L1(WM, P) real | L1 floor (exact kernel, 1358 draws) | L1(B, P) | I_z canonical |
|---|---|---|---|---|---|---|---|---|---|---|
| uncontrollable_deterministic | uncontrollable_deterministic | 0.0122 [0.0004], 0.0013 | 0.0138 | 0.0033 [0.0002] | 0.1489 [0.0070], 25/25 | 0.3674 | 0.0289 | 0.0000 | 0.0300 | 0.9010 |
| controllable_noisy | controllable_noisy | 1.8534 [0.0030], 0.0056 | 0.0404 | 1.8030 [0.0031] | 2.1621 [0.0030], 25/25 | 2.7719 | 0.1820 | 0.0200 | 0.0703 | 1.8256 |
| uncontrollable_noisy | uncontrollable_noisy | 0.0253 [0.0006], 0.0042 | 0.0559 | 0.0098 [0.0004] | 0.2208 [0.0051], 25/25 | 2.8462 | 0.1883 | 0.0200 | 0.0749 | 0.9585 |
| controllable_deterministic | controllable_deterministic | 2.3131 [0.0006], 0.0004 | 0.0027 | 2.3040 [0.0008] | 2.3217 [0.0012], 25/25 | 0.0549 | 0.0073 | 0.0000 | 0.0098 | 2.1768 |

Template accuracies: acc_replay_hard 1.0000, acc_real_context 0.9980, acc_canonical_hard 0.5028, acc_canonical_mode 0.5208
z-only probe test accuracy: 0.9984; h-only: 0.8831; on the real contexts h -> s 0.9276, z -> s 0.9993
p_hat(frequent outcome), real contexts: controllable_noisy 0.8879, uncontrollable_noisy 0.8926
D1 (real contexts): 8 / 12 pairs accepted.
D2 (real contexts): boundary 4.8342, within-zone 4.0381.
