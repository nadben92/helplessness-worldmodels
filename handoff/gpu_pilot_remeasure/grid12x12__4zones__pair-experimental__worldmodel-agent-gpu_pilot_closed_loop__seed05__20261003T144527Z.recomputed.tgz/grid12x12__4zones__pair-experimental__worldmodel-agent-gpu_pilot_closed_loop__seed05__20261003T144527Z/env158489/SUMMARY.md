# Recomputed measures -- env 158489 (gradient step 94939)

Real contexts: 7095 contexts, 144 / 144 states measured (not measured: none).

| zone | dynamics | I_s real, MAIN (mean [se], bias) | off-support mass | I_s projected, secondary (mean [se]) | I_z real, secondary (mean [se], n measured) | KL real (bits) | L1(WM, P) real | L1 floor (exact kernel, 1358 draws) | L1(B, P) | I_z canonical |
|---|---|---|---|---|---|---|---|---|---|---|
| uncontrollable_deterministic | uncontrollable_deterministic | 0.0241 [0.0006], 0.0026 | 0.0280 | 0.0076 [0.0003] | 0.2342 [0.0081], 25/25 | 0.6644 | 0.0599 | 0.0000 | 0.0463 | 0.8008 |
| controllable_noisy | controllable_noisy | 1.8172 [0.0030], 0.0058 | 0.0544 | 1.7591 [0.0032] | 2.1544 [0.0030], 25/25 | 2.8980 | 0.2091 | 0.0200 | 0.0770 | 1.8602 |
| uncontrollable_noisy | uncontrollable_noisy | 0.0352 [0.0007], 0.0047 | 0.1005 | 0.0141 [0.0005] | 0.2907 [0.0060], 25/25 | 3.0700 | 0.3053 | 0.0200 | 0.0955 | 0.7701 |
| controllable_deterministic | controllable_deterministic | 2.2945 [0.0009], 0.0008 | 0.0073 | 2.2731 [0.0012] | 2.3202 [0.0013], 25/25 | 0.1632 | 0.0206 | 0.0000 | 0.0129 | 2.2021 |

Template accuracies: acc_replay_hard 0.9980, acc_real_context 0.9984, acc_canonical_hard 0.5403, acc_canonical_mode 0.5972
z-only probe test accuracy: 0.9981; h-only: 0.8828; on the real contexts h -> s 0.9084, z -> s 0.9958
p_hat(frequent outcome), real contexts: controllable_noisy 0.8692, uncontrollable_noisy 0.8148
D1 (real contexts): 8 / 12 pairs accepted.
D2 (real contexts): boundary 4.7850, within-zone 3.9386.
