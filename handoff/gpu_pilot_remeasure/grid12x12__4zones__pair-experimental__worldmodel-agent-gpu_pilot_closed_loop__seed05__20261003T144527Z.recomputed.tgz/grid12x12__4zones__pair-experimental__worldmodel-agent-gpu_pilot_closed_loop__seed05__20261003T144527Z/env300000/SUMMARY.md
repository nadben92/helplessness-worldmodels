# Recomputed measures -- env 300000 (gradient step 179846)

Real contexts: 7118 contexts, 144 / 144 states measured (not measured: none).

| zone | dynamics | I_s real, MAIN (mean [se], bias) | off-support mass | I_s projected, secondary (mean [se]) | I_z real, secondary (mean [se], n measured) | KL real (bits) | L1(WM, P) real | L1 floor (exact kernel, 1358 draws) | L1(B, P) | I_z canonical |
|---|---|---|---|---|---|---|---|---|---|---|
| uncontrollable_deterministic | uncontrollable_deterministic | 0.0081 [0.0003], 0.0009 | 0.0087 | 0.0022 [0.0002] | 0.1116 [0.0063], 25/25 | 0.2668 | 0.0183 | 0.0000 | 0.0253 | 0.8321 |
| controllable_noisy | controllable_noisy | 1.8607 [0.0030], 0.0050 | 0.0354 | 1.8210 [0.0032] | 2.1621 [0.0030], 25/25 | 2.8222 | 0.1722 | 0.0200 | 0.0682 | 1.8678 |
| uncontrollable_noisy | uncontrollable_noisy | 0.0215 [0.0006], 0.0040 | 0.0473 | 0.0088 [0.0004] | 0.1890 [0.0044], 25/25 | 2.8851 | 0.1769 | 0.0200 | 0.0672 | 0.9885 |
| controllable_deterministic | controllable_deterministic | 2.3147 [0.0005], 0.0002 | 0.0026 | 2.3042 [0.0008] | 2.3217 [0.0012], 25/25 | 0.0544 | 0.0067 | 0.0000 | 0.0089 | 2.1460 |

Template accuracies: acc_replay_hard 1.0000, acc_real_context 0.9993, acc_canonical_hard 0.5028, acc_canonical_mode 0.5000
z-only probe test accuracy: 0.9988; h-only: 0.8778; on the real contexts h -> s 0.9037, z -> s 0.9993
p_hat(frequent outcome), real contexts: controllable_noisy 0.8947, uncontrollable_noisy 0.9095
D1 (real contexts): 8 / 12 pairs accepted.
D2 (real contexts): boundary 4.8557, within-zone 4.0950.
