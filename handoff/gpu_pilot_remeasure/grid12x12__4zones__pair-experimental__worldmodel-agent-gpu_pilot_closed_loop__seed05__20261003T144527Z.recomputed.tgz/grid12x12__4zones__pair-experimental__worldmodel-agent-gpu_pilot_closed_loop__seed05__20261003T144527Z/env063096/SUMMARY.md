# Recomputed measures -- env 63096 (gradient step 37703)

Real contexts: 6862 contexts, 144 / 144 states measured (not measured: none).

| zone | dynamics | I_s real, MAIN (mean [se], bias) | off-support mass | I_s projected, secondary (mean [se]) | I_z real, secondary (mean [se], n measured) | KL real (bits) | L1(WM, P) real | L1 floor (exact kernel, 1358 draws) | L1(B, P) | I_z canonical |
|---|---|---|---|---|---|---|---|---|---|---|
| uncontrollable_deterministic | uncontrollable_deterministic | 0.0836 [0.0011], 0.0048 | 0.1876 | 0.0264 [0.0006] | 0.5748 [0.0101], 25/25 | 3.0882 | 0.4050 | 0.0000 | 0.1195 | 0.9386 |
| controllable_noisy | controllable_noisy | 1.7223 [0.0029], 0.0066 | 0.1010 | 1.6551 [0.0032] | 2.1313 [0.0026], 25/25 | 4.2151 | 0.3273 | 0.0200 | 0.0956 | 1.9150 |
| uncontrollable_noisy | uncontrollable_noisy | 0.0742 [0.0011], 0.0059 | 0.2608 | 0.0333 [0.0007] | 0.5075 [0.0075], 25/25 | 4.5848 | 0.7151 | 0.0200 | 0.1240 | 0.6701 |
| controllable_deterministic | controllable_deterministic | 2.1947 [0.0014], 0.0023 | 0.0316 | 2.1449 [0.0018] | 2.2942 [0.0017], 25/25 | 0.8015 | 0.0994 | 0.0000 | 0.0256 | 2.2065 |

Template accuracies: acc_replay_hard 1.0000, acc_real_context 0.9937, acc_canonical_hard 0.6208, acc_canonical_mode 0.6389
z-only probe test accuracy: 0.9970; h-only: 0.9046; on the real contexts h -> s 0.8907, z -> s 0.9927
p_hat(frequent outcome), real contexts: controllable_noisy 0.8092, uncontrollable_noisy 0.6061
D1 (real contexts): 8 / 12 pairs accepted.
D2 (real contexts): boundary 4.7167, within-zone 3.7814.
