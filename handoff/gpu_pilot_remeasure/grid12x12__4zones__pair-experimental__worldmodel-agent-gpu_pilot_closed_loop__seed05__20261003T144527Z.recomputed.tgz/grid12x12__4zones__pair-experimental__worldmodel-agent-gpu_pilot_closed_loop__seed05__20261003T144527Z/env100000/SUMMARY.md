# Recomputed measures -- env 100000 (gradient step 59846)

Real contexts: 7044 contexts, 144 / 144 states measured (not measured: none).

| zone | dynamics | I_s real, MAIN (mean [se], bias) | off-support mass | I_s projected, secondary (mean [se]) | I_z real, secondary (mean [se], n measured) | KL real (bits) | L1(WM, P) real | L1 floor (exact kernel, 1358 draws) | L1(B, P) | I_z canonical |
|---|---|---|---|---|---|---|---|---|---|---|
| uncontrollable_deterministic | uncontrollable_deterministic | 0.0501 [0.0008], 0.0038 | 0.0937 | 0.0152 [0.0005] | 0.3864 [0.0096], 25/25 | 1.6918 | 0.2035 | 0.0000 | 0.0765 | 0.8938 |
| controllable_noisy | controllable_noisy | 1.7990 [0.0029], 0.0056 | 0.0672 | 1.7416 [0.0032] | 2.1468 [0.0027], 25/25 | 3.7579 | 0.2413 | 0.0200 | 0.0842 | 1.8597 |
| uncontrollable_noisy | uncontrollable_noisy | 0.0490 [0.0009], 0.0051 | 0.1705 | 0.0224 [0.0006] | 0.3605 [0.0069], 25/25 | 3.7460 | 0.5139 | 0.0200 | 0.1116 | 0.6502 |
| controllable_deterministic | controllable_deterministic | 2.2575 [0.0012], 0.0021 | 0.0212 | 2.2129 [0.0016] | 2.3133 [0.0015], 25/25 | 0.4640 | 0.0565 | 0.0000 | 0.0190 | 2.2170 |

Template accuracies: acc_replay_hard 1.0000, acc_real_context 0.9957, acc_canonical_hard 0.5486, acc_canonical_mode 0.5764
z-only probe test accuracy: 0.9973; h-only: 0.8940; on the real contexts h -> s 0.9027, z -> s 0.9922
p_hat(frequent outcome), real contexts: controllable_noisy 0.8526, uncontrollable_noisy 0.7083
D1 (real contexts): 8 / 12 pairs accepted.
D2 (real contexts): boundary 4.6954, within-zone 3.8120.
