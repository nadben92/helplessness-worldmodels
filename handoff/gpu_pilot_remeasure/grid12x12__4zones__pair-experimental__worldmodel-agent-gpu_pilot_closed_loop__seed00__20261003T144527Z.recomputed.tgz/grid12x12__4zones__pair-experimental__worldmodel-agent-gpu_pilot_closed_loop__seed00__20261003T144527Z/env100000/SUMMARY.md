# Recomputed measures -- env 100000 (gradient step 59846)

Real contexts: 7122 contexts, 144 / 144 states measured (not measured: none).

| zone | dynamics | I_s real, MAIN (mean [se], bias) | off-support mass | I_s projected, secondary (mean [se]) | I_z real, secondary (mean [se], n measured) | KL real (bits) | L1(WM, P) real | L1 floor (exact kernel, 1358 draws) | L1(B, P) | I_z canonical |
|---|---|---|---|---|---|---|---|---|---|---|
| uncontrollable_deterministic | uncontrollable_deterministic | 0.0217 [0.0006], 0.0018 | 0.0357 | 0.0072 [0.0003] | 0.2053 [0.0068], 25/25 | 0.7648 | 0.1021 | 0.0000 | 0.0540 | 0.9764 |
| controllable_noisy | controllable_noisy | 1.7252 [0.0031], 0.0084 | 0.1249 | 1.5692 [0.0032] | 2.1593 [0.0028], 25/25 | 4.2281 | 0.3426 | 0.0200 | 0.1075 | 2.0122 |
| uncontrollable_noisy | uncontrollable_noisy | 0.0589 [0.0009], 0.0089 | 0.1459 | 0.0208 [0.0006] | 0.4053 [0.0068], 25/25 | 4.1579 | 0.3946 | 0.0200 | 0.1118 | 0.7259 |
| controllable_deterministic | controllable_deterministic | 2.2561 [0.0012], 0.0011 | 0.0125 | 2.2348 [0.0014] | 2.3071 [0.0016], 25/25 | 0.1708 | 0.0443 | 0.0000 | 0.0256 | 2.2576 |

Template accuracies: acc_replay_hard 1.0000, acc_real_context 0.9958, acc_canonical_hard 0.5056, acc_canonical_mode 0.5417
z-only probe test accuracy: 0.9986; h-only: 0.8906; on the real contexts h -> s 0.9045, z -> s 0.9944
p_hat(frequent outcome), real contexts: controllable_noisy 0.7993, uncontrollable_noisy 0.7989
D1 (real contexts): 8 / 12 pairs accepted.
D2 (real contexts): boundary 5.1395, within-zone 3.9685.
