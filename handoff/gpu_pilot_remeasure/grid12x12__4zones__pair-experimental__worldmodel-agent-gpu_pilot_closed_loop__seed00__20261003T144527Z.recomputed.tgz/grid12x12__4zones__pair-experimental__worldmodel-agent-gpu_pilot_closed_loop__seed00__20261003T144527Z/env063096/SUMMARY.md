# Recomputed measures -- env 63096 (gradient step 37703)

Real contexts: 7048 contexts, 144 / 144 states measured (not measured: none).

| zone | dynamics | I_s real, MAIN (mean [se], bias) | off-support mass | I_s projected, secondary (mean [se]) | I_z real, secondary (mean [se], n measured) | KL real (bits) | L1(WM, P) real | L1 floor (exact kernel, 1358 draws) | L1(B, P) | I_z canonical |
|---|---|---|---|---|---|---|---|---|---|---|
| uncontrollable_deterministic | uncontrollable_deterministic | 0.0441 [0.0008], 0.0026 | 0.0648 | 0.0202 [0.0006] | 0.3516 [0.0078], 25/25 | 1.2668 | 0.1963 | 0.0000 | 0.0840 | 0.9276 |
| controllable_noisy | controllable_noisy | 1.5121 [0.0030], 0.0100 | 0.2008 | 1.3395 [0.0032] | 2.0732 [0.0032], 25/25 | 5.1964 | 0.5317 | 0.0200 | 0.1239 | 1.9834 |
| uncontrollable_noisy | uncontrollable_noisy | 0.0898 [0.0012], 0.0119 | 0.2851 | 0.0303 [0.0007] | 0.5476 [0.0084], 25/25 | 5.4700 | 0.6762 | 0.0200 | 0.1431 | 0.8290 |
| controllable_deterministic | controllable_deterministic | 2.2043 [0.0014], 0.0015 | 0.0332 | 2.1558 [0.0016] | 2.2933 [0.0017], 25/25 | 0.3371 | 0.0992 | 0.0000 | 0.0325 | 2.2348 |

Template accuracies: acc_replay_hard 0.9941, acc_real_context 0.9933, acc_canonical_hard 0.7028, acc_canonical_mode 0.7292
z-only probe test accuracy: 0.9981; h-only: 0.8944; on the real contexts h -> s 0.9120, z -> s 0.9979
p_hat(frequent outcome), real contexts: controllable_noisy 0.6972, uncontrollable_noisy 0.6484
D1 (real contexts): 8 / 12 pairs accepted.
D2 (real contexts): boundary 5.1711, within-zone 3.9287.
