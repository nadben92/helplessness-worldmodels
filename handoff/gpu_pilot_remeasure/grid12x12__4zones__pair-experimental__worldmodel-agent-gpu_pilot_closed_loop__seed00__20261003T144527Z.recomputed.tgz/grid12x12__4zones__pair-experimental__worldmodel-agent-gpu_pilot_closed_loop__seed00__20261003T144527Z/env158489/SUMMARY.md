# Recomputed measures -- env 158489 (gradient step 94939)

Real contexts: 7163 contexts, 144 / 144 states measured (not measured: none).

| zone | dynamics | I_s real, MAIN (mean [se], bias) | off-support mass | I_s projected, secondary (mean [se]) | I_z real, secondary (mean [se], n measured) | KL real (bits) | L1(WM, P) real | L1 floor (exact kernel, 1358 draws) | L1(B, P) | I_z canonical |
|---|---|---|---|---|---|---|---|---|---|---|
| uncontrollable_deterministic | uncontrollable_deterministic | 0.0100 [0.0004], 0.0009 | 0.0192 | 0.0036 [0.0002] | 0.1235 [0.0054], 25/25 | 0.3904 | 0.0501 | 0.0000 | 0.0344 | 0.8423 |
| controllable_noisy | controllable_noisy | 1.8244 [0.0029], 0.0085 | 0.0960 | 1.6788 [0.0033] | 2.1903 [0.0030], 25/25 | 3.6530 | 0.2694 | 0.0200 | 0.0922 | 2.0041 |
| uncontrollable_noisy | uncontrollable_noisy | 0.0387 [0.0008], 0.0074 | 0.0791 | 0.0144 [0.0005] | 0.2794 [0.0056], 25/25 | 3.3016 | 0.2498 | 0.0200 | 0.0928 | 0.6142 |
| controllable_deterministic | controllable_deterministic | 2.2850 [0.0009], 0.0008 | 0.0065 | 2.2749 [0.0011] | 2.3130 [0.0015], 25/25 | 0.0937 | 0.0236 | 0.0000 | 0.0210 | 2.2604 |

Template accuracies: acc_replay_hard 1.0000, acc_real_context 0.9976, acc_canonical_hard 0.3444, acc_canonical_mode 0.3889
z-only probe test accuracy: 0.9990; h-only: 0.8860; on the real contexts h -> s 0.8959, z -> s 0.9972
p_hat(frequent outcome), real contexts: controllable_noisy 0.8420, uncontrollable_noisy 0.8785
D1 (real contexts): 8 / 12 pairs accepted.
D2 (real contexts): boundary 5.1739, within-zone 4.0108.
