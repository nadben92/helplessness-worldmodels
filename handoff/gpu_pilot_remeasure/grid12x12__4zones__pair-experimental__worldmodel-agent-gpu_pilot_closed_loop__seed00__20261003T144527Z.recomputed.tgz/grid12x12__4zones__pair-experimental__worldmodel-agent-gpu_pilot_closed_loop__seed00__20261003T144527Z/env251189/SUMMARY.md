# Recomputed measures -- env 251189 (gradient step 150559)

Real contexts: 7194 contexts, 144 / 144 states measured (not measured: none).

| zone | dynamics | I_s real, MAIN (mean [se], bias) | off-support mass | I_s projected, secondary (mean [se]) | I_z real, secondary (mean [se], n measured) | KL real (bits) | L1(WM, P) real | L1 floor (exact kernel, 1358 draws) | L1(B, P) | I_z canonical |
|---|---|---|---|---|---|---|---|---|---|---|
| uncontrollable_deterministic | uncontrollable_deterministic | 0.0061 [0.0003], 0.0006 | 0.0076 | 0.0022 [0.0002] | 0.0811 [0.0044], 25/25 | 0.2084 | 0.0230 | 0.0000 | 0.0223 | 0.9563 |
| controllable_noisy | controllable_noisy | 1.9087 [0.0029], 0.0070 | 0.0607 | 1.8023 [0.0032] | 2.2108 [0.0027], 25/25 | 3.6530 | 0.2022 | 0.0200 | 0.0812 | 1.9956 |
| uncontrollable_noisy | uncontrollable_noisy | 0.0301 [0.0007], 0.0067 | 0.0547 | 0.0105 [0.0004] | 0.2156 [0.0050], 25/25 | 2.8741 | 0.1966 | 0.0200 | 0.0731 | 0.6431 |
| controllable_deterministic | controllable_deterministic | 2.2964 [0.0008], 0.0005 | 0.0055 | 2.2842 [0.0010] | 2.3163 [0.0014], 25/25 | 0.0558 | 0.0175 | 0.0000 | 0.0162 | 2.2128 |

Template accuracies: acc_replay_hard 0.9961, acc_real_context 0.9986, acc_canonical_hard 0.2833, acc_canonical_mode 0.3681
z-only probe test accuracy: 0.9989; h-only: 0.8823; on the real contexts h -> s 0.9082, z -> s 0.9986
p_hat(frequent outcome), real contexts: controllable_noisy 0.8868, uncontrollable_noisy 0.9065
D1 (real contexts): 8 / 12 pairs accepted.
D2 (real contexts): boundary 5.1860, within-zone 4.0551.
