# Recomputed measures -- env 300000 (gradient step 179846)

Real contexts: 7198 contexts, 144 / 144 states measured (not measured: none).

| zone | dynamics | I_s real, MAIN (mean [se], bias) | off-support mass | I_s projected, secondary (mean [se]) | I_z real, secondary (mean [se], n measured) | KL real (bits) | L1(WM, P) real | L1 floor (exact kernel, 1358 draws) | L1(B, P) | I_z canonical |
|---|---|---|---|---|---|---|---|---|---|---|
| uncontrollable_deterministic | uncontrollable_deterministic | 0.0057 [0.0003], 0.0007 | 0.0073 | 0.0017 [0.0002] | 0.0701 [0.0045], 25/25 | 0.2144 | 0.0241 | 0.0000 | 0.0187 | 0.9352 |
| controllable_noisy | controllable_noisy | 1.9014 [0.0029], 0.0076 | 0.0573 | 1.7899 [0.0032] | 2.2026 [0.0032], 25/25 | 3.3231 | 0.1991 | 0.0200 | 0.0757 | 1.9622 |
| uncontrollable_noisy | uncontrollable_noisy | 0.0286 [0.0007], 0.0069 | 0.0542 | 0.0093 [0.0004] | 0.2081 [0.0050], 25/25 | 3.0693 | 0.1969 | 0.0200 | 0.0661 | 0.6282 |
| controllable_deterministic | controllable_deterministic | 2.2964 [0.0008], 0.0005 | 0.0044 | 2.2887 [0.0010] | 2.3167 [0.0013], 25/25 | 0.0460 | 0.0155 | 0.0000 | 0.0143 | 2.1628 |

Template accuracies: acc_replay_hard 1.0000, acc_real_context 0.9986, acc_canonical_hard 0.2861, acc_canonical_mode 0.3819
z-only probe test accuracy: 0.9987; h-only: 0.8810; on the real contexts h -> s 0.9062, z -> s 0.9972
p_hat(frequent outcome), real contexts: controllable_noisy 0.8887, uncontrollable_noisy 0.9110
D1 (real contexts): 8 / 12 pairs accepted.
D2 (real contexts): boundary 5.1777, within-zone 4.0631.
