# Recomputed measures -- final (gradient step 200)

Real contexts: 7100 contexts, 143 / 144 states measured (not measured: [0]).

| zone | dynamics | I_s real, MAIN (mean [se], bias) | I_z real, secondary (mean [se], n measured) | KL real (bits) | L1(WM, P) real | L1 floor (exact kernel, 1358 draws) | L1(B, P) | I_z canonical |
|---|---|---|---|---|---|---|---|---|
| uncontrollable_deterministic | uncontrollable_deterministic | 0.0345 [0.0008], 0.0227 | -0.0030 [0.0015], 25/25 | 0.0128 | 1.9455 | 0.0000 | 0.0615 | 0.0048 |
| controllable_noisy | controllable_noisy | 0.0336 [0.0008], 0.0227 | -0.0006 [0.0014], 25/25 | 0.0132 | 1.9946 | 0.0200 | 0.0604 | 0.0001 |
| uncontrollable_noisy | uncontrollable_noisy | 0.0327 [0.0008], 0.0231 | 0.0004 [0.0014], 25/25 | 0.0131 | 1.9728 | 0.0200 | 0.1209 | -0.0018 |
| controllable_deterministic | controllable_deterministic | 0.0324 [0.0008], 0.0229 | 0.0011 [0.0014], 25/25 | 0.0126 | 1.9943 | 0.0000 | 0.0121 | -0.0009 |

Template accuracies: acc_replay_hard 0.0117, acc_real_context 0.0066, acc_canonical_hard 0.0042, acc_canonical_mode 0.0069
z-only probe test accuracy: 0.0279; h-only: 0.0318; on the real contexts h -> s 0.0092, z -> s 0.0063
p_hat(frequent outcome), real contexts: controllable_noisy 0.2502, uncontrollable_noisy 0.2516
D1 (real contexts): 0 / 12 pairs accepted.
D2 (real contexts): boundary 0.0001, within-zone 0.0001.
