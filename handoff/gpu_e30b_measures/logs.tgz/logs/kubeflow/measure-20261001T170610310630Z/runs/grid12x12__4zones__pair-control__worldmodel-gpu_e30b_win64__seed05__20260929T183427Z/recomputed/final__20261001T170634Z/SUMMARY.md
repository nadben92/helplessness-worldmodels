# Recomputed measures -- final (gradient step 60000)

Real contexts: 7150 contexts, 143 / 144 states measured (not measured: [0]).

| zone | dynamics | I_s real, MAIN (mean [se], bias) | off-support mass | I_s projected, secondary (mean [se]) | I_z real, secondary (mean [se], n measured) | KL real (bits) | L1(WM, P) real | L1 floor (exact kernel, 1358 draws) | L1(B, P) | I_z canonical |
|---|---|---|---|---|---|---|---|---|---|---|
| uncontrollable_deterministic | controllable_deterministic | 2.2969 [0.0009], 0.0007 | 0.0051 | 2.2789 [0.0012] | 2.3174 [0.0014], 25/25 | 0.2295 | 0.0158 | 0.0000 | 0.0114 | 2.2409 |
| controllable_noisy | controllable_noisy | 1.9455 [0.0028], 0.0040 | 0.0416 | 1.9010 [0.0030] | 2.2217 [0.0025], 25/25 | 3.5480 | 0.1707 | 0.0200 | 0.0615 | 1.8923 |
| uncontrollable_noisy | controllable_noisy | 1.7850 [0.0031], 0.0029 | 0.0527 | 1.7523 [0.0033] | 2.1465 [0.0027], 25/25 | 3.0751 | 0.2073 | 0.0200 | 0.0635 | 1.9060 |
| controllable_deterministic | controllable_deterministic | 2.3009 [0.0008], 0.0008 | 0.0070 | 2.2862 [0.0011] | 2.3219 [0.0014], 25/25 | 0.2773 | 0.0185 | 0.0000 | 0.0116 | 2.2652 |

Template accuracies: acc_replay_hard 0.9980, acc_real_context 0.9979, acc_canonical_hard 0.3931, acc_canonical_mode 0.4097
z-only probe test accuracy: 0.9981; h-only: 0.9079; on the real contexts h -> s 0.9301, z -> s 0.9958
p_hat(frequent outcome), real contexts: controllable_noisy 0.9038, uncontrollable_noisy 0.8608
D1 (real contexts): 0 / 12 pairs accepted.
D2 (real contexts): boundary 3.9778, within-zone 3.6389.
