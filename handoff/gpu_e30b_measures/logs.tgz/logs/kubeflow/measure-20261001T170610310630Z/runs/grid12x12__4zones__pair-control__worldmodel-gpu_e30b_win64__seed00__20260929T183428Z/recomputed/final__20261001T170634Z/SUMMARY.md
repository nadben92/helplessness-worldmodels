# Recomputed measures -- final (gradient step 60000)

Real contexts: 7150 contexts, 143 / 144 states measured (not measured: [0]).

| zone | dynamics | I_s real, MAIN (mean [se], bias) | off-support mass | I_s projected, secondary (mean [se]) | I_z real, secondary (mean [se], n measured) | KL real (bits) | L1(WM, P) real | L1 floor (exact kernel, 1358 draws) | L1(B, P) | I_z canonical |
|---|---|---|---|---|---|---|---|---|---|---|
| uncontrollable_deterministic | controllable_deterministic | 2.2594 [0.0014], 0.0009 | 0.0085 | 2.2488 [0.0015] | 2.3116 [0.0015], 25/25 | 0.2489 | 0.0328 | 0.0000 | 0.0113 | 2.2437 |
| controllable_noisy | controllable_noisy | 1.9368 [0.0028], 0.0040 | 0.0374 | 1.8736 [0.0030] | 2.1884 [0.0025], 25/25 | 2.9866 | 0.1559 | 0.0200 | 0.0590 | 1.9746 |
| uncontrollable_noisy | controllable_noisy | 1.8417 [0.0030], 0.0034 | 0.0457 | 1.7937 [0.0032] | 2.1364 [0.0027], 25/25 | 3.1014 | 0.1867 | 0.0200 | 0.0619 | 2.0843 |
| controllable_deterministic | controllable_deterministic | 2.2929 [0.0010], 0.0004 | 0.0063 | 2.2720 [0.0013] | 2.3159 [0.0015], 25/25 | 0.2403 | 0.0191 | 0.0000 | 0.0118 | 2.2773 |

Template accuracies: acc_replay_hard 1.0000, acc_real_context 0.9978, acc_canonical_hard 0.4319, acc_canonical_mode 0.4722
z-only probe test accuracy: 0.9952; h-only: 0.9064; on the real contexts h -> s 0.9434, z -> s 0.9958
p_hat(frequent outcome), real contexts: controllable_noisy 0.9066, uncontrollable_noisy 0.8774
D1 (real contexts): 0 / 12 pairs accepted.
D2 (real contexts): boundary 3.6884, within-zone 3.2063.
