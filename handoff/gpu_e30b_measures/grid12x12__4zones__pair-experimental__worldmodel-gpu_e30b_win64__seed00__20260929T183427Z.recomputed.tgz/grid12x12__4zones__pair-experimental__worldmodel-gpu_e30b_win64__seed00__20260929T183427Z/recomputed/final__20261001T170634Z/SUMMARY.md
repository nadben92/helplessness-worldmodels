# Recomputed measures -- final (gradient step 60000)

Real contexts: 7100 contexts, 143 / 144 states measured (not measured: [0]).

| zone | dynamics | I_s real, MAIN (mean [se], bias) | off-support mass | I_s projected, secondary (mean [se]) | I_z real, secondary (mean [se], n measured) | KL real (bits) | L1(WM, P) real | L1 floor (exact kernel, 1358 draws) | L1(B, P) | I_z canonical |
|---|---|---|---|---|---|---|---|---|---|---|
| uncontrollable_deterministic | uncontrollable_deterministic | 0.0200 [0.0006], 0.0014 | 0.0472 | 0.0055 [0.0003] | 0.1761 [0.0048], 25/25 | 0.6882 | 0.1237 | 0.0000 | 0.0615 | 0.6283 |
| controllable_noisy | controllable_noisy | 1.9453 [0.0027], 0.0052 | 0.0498 | 1.8661 [0.0031] | 2.2030 [0.0026], 25/25 | 3.4478 | 0.1877 | 0.0200 | 0.0604 | 1.9993 |
| uncontrollable_noisy | uncontrollable_noisy | 0.0496 [0.0009], 0.0077 | 0.1573 | 0.0160 [0.0005] | 0.3330 [0.0065], 25/25 | 4.2784 | 0.4536 | 0.0200 | 0.1209 | 0.5783 |
| controllable_deterministic | controllable_deterministic | 2.2901 [0.0010], 0.0006 | 0.0048 | 2.2813 [0.0011] | 2.3144 [0.0014], 25/25 | 0.1836 | 0.0174 | 0.0000 | 0.0121 | 2.1792 |

Template accuracies: acc_replay_hard 0.9961, acc_real_context 0.9972, acc_canonical_hard 0.6569, acc_canonical_mode 0.7083
z-only probe test accuracy: 0.9975; h-only: 0.9175; on the real contexts h -> s 0.9254, z -> s 0.9887
p_hat(frequent outcome), real contexts: controllable_noisy 0.8972, uncontrollable_noisy 0.7664
D1 (real contexts): 8 / 12 pairs accepted.
D2 (real contexts): boundary 4.8166, within-zone 3.2784.
