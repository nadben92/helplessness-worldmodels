# Recomputed measures -- final (gradient step 60000)

Real contexts: 7095 contexts, 143 / 144 states measured (not measured: [0]).

| zone | dynamics | I_s real, MAIN (mean [se], bias) | off-support mass | I_s projected, secondary (mean [se]) | I_z real, secondary (mean [se], n measured) | KL real (bits) | L1(WM, P) real | L1 floor (exact kernel, 1358 draws) | L1(B, P) | I_z canonical |
|---|---|---|---|---|---|---|---|---|---|---|
| uncontrollable_deterministic | uncontrollable_deterministic | 0.0287 [0.0007], 0.0026 | 0.0596 | 0.0099 [0.0004] | 0.3252 [0.0073], 25/25 | 1.0990 | 0.1341 | 0.0000 | 0.0623 | 0.9429 |
| controllable_noisy | controllable_noisy | 1.9415 [0.0028], 0.0041 | 0.0431 | 1.8952 [0.0030] | 2.2153 [0.0025], 25/25 | 3.0932 | 0.1768 | 0.0200 | 0.0599 | 1.9349 |
| uncontrollable_noisy | uncontrollable_noisy | 0.0346 [0.0007], 0.0048 | 0.1421 | 0.0148 [0.0005] | 0.2980 [0.0064], 25/25 | 3.3268 | 0.4377 | 0.0200 | 0.1198 | 0.5458 |
| controllable_deterministic | controllable_deterministic | 2.2919 [0.0009], 0.0008 | 0.0079 | 2.2691 [0.0013] | 2.3165 [0.0014], 25/25 | 0.2766 | 0.0230 | 0.0000 | 0.0117 | 2.2407 |

Template accuracies: acc_replay_hard 0.9980, acc_real_context 0.9958, acc_canonical_hard 0.4681, acc_canonical_mode 0.4931
z-only probe test accuracy: 0.9987; h-only: 0.9159; on the real contexts h -> s 0.9056, z -> s 0.9958
p_hat(frequent outcome), real contexts: controllable_noisy 0.9005, uncontrollable_noisy 0.7611
D1 (real contexts): 8 / 12 pairs accepted.
D2 (real contexts): boundary 4.7340, within-zone 3.7624.
